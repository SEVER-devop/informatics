function zz = fun2(x, y)
    zz = [-y(1) + 8*y(2); 
            y(1) + y(2)];
end
