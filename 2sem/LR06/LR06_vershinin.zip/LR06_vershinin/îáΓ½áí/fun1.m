function z = fun1(x, y)
    z = exp(-sin(x)) - y * cos(x);
end